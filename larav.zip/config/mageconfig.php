<?php

return [
    'apiurl' => 'http://magestore.localhost/rest/V1/',
    'username' => 'admin',
    'password' => 'admin@123',
];
