<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Validator;
use App\Models\Booking;

class StoreBookingRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'event_id' => 'required|exists:events,id',
            'attendee_id' => 'required|exists:attendees,id',
        ];
    }

    public function withValidator(Validator $validator): void
    {
        $validator->after(function ($validator) {
            $exists = Booking::where('event_id', $this->event_id)
                ->where('attendee_id', $this->attendee_id)
                ->exists();

            if ($exists) {
                $validator->errors()->add('booking', 'Attendee has already booked this event.');
            }
        });
    }
}

