<?php

namespace App\Http\Controllers\Api;

use App\Models\Booking;
use App\Models\Event;
use App\Models\Attendee;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class BookingController extends Controller
{
    public function store(Request $request)
    {
        $data = $request->validate([
            'event_id' => 'required|exists:events,id',
            'attendee_id' => 'required|exists:attendees,id',
        ]);

        $data['booking_time'] = now();

        $booking = Booking::create($data);
        return response()->json($booking, 201);
    }

    public function show($id)
    {
        $booking = Booking::with(['event', 'attendee'])->findOrFail($id);
        return response()->json($booking);
    }

    public function destroy($id)
    {
        Booking::findOrFail($id)->delete();
        return response()->json(null, 204);
    }
}

